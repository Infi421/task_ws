
"use strict";

let direction = require('./direction.js');

module.exports = {
  direction: direction,
};
